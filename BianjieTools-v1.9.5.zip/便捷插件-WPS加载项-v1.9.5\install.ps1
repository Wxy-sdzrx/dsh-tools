﻿<#
  便捷插件 · WPS 文字加载项 —— 安装
  双击同目录的「安装.bat」即可；也可右键本文件「使用 PowerShell 运行」。
  纯文件部署到当前用户的 %APPDATA%，不需要管理员权限，不写注册表。
#>
$ErrorActionPreference = 'Stop'
try { [Console]::OutputEncoding = [System.Text.Encoding]::UTF8 } catch {}

$Name    = 'BianjieTools'
$Version = '1.9.5'
$Here    = $PSScriptRoot
$Src     = Join-Path $Here ($Name + '_' + $Version)
$JsAddons = Join-Path $env:APPDATA 'kingsoft\wps\jsaddons'
$Target   = Join-Path $JsAddons ($Name + '_' + $Version)
$Pub      = Join-Path $JsAddons 'publish.xml'

Write-Host ''
Write-Host '=== 便捷插件 · 安装 ===' -ForegroundColor Cyan
Write-Host ''

# --- 前置检查 ---
if (-not (Test-Path $Src)) {
    Write-Host ('[错误] 找不到加载项文件夹: ' + $Src) -ForegroundColor Red
    Write-Host '        请确认压缩包已完整解压（不要直接在压缩包里运行）。'
    exit 1
}
if (-not (Test-Path (Join-Path $env:APPDATA 'kingsoft'))) {
    Write-Host '[警告] 没检测到 %APPDATA%\kingsoft，本机可能没装 WPS。' -ForegroundColor Yellow
}
$wps = Get-Process wps, et, wpp -ErrorAction SilentlyContinue
if ($wps) {
    Write-Host '[警告] WPS 正在运行。安装会照常完成，但必须完全退出 WPS 后重开才生效。' -ForegroundColor Yellow
}

# --- 部署文件 ---
New-Item -ItemType Directory -Force -Path $JsAddons | Out-Null
if (Test-Path $Target) { Remove-Item $Target -Recurse -Force -ErrorAction SilentlyContinue }
Copy-Item $Src $Target -Recurse -Force
Write-Host ('[1/2] 已部署文件 -> ' + $Target)

# --- 合并 publish.xml（已存在则只追加自己的条目，不覆盖别人的） ---
[xml]$doc = $null
if (Test-Path $Pub) {
    try { [xml]$doc = Get-Content $Pub -Raw -Encoding UTF8 } catch { $doc = $null }
}
if ($doc -eq $null -or $doc.DocumentElement -eq $null) {
    $doc = New-Object System.Xml.XmlDocument
    $doc.AppendChild($doc.CreateXmlDeclaration('1.0', 'UTF-8', $null)) | Out-Null
    $doc.AppendChild($doc.CreateElement('jsplugins')) | Out-Null
}
$rootEl = $doc.DocumentElement
# 本插件的所有历史名字都要清 —— 只删同名会让改名前的旧条目残留，
# 而旧条目指向的目录已被删除，WPS 会去加载一个不存在的加载项。
$OldNames = @('DshNumberTools', 'DadiJiubuTools')
foreach ($n in @($rootEl.SelectNodes('jsplugin'))) {
    $nm = $n.GetAttribute('name')
    if ($nm -eq $Name -or ($OldNames -contains $nm)) { $rootEl.RemoveChild($n) | Out-Null }
}
$el = $doc.CreateElement('jsplugin')
$el.SetAttribute('name', $Name)
$el.SetAttribute('enable', 'enable_dev')
$el.SetAttribute('url', 'file://')
$el.SetAttribute('type', 'wps')
$el.SetAttribute('version', $Version)
$rootEl.AppendChild($el) | Out-Null
$doc.Save($Pub)

# 迁移：清掉改名前的旧名字，以及本插件的历史版本目录（只保留当前版本）
foreach ($oldName in @('DshNumberTools', 'DadiJiubuTools', $Name)) {
    foreach ($od in @(Get-ChildItem $JsAddons -Directory -Filter ($oldName + '_*') -ErrorAction SilentlyContinue)) {
        if ($od.FullName -eq $Target) { continue }
        Remove-Item $od.FullName -Recurse -Force -ErrorAction SilentlyContinue
        Write-Host ('已清理旧版目录: ' + $od.Name)
    }
}
Write-Host ('[2/2] 已写入配置 -> ' + $Pub)

Write-Host ''
Write-Host '安装完成。' -ForegroundColor Green
Write-Host ''
Write-Host '接下来必须做这一步（否则不会生效）：'
Write-Host '  完全退出 WPS —— 右键任务栏 WPS 图标选「退出」；'
Write-Host '  必要时在任务管理器里确认所有 wps.exe 都没了（含托盘和云文档进程）。'
Write-Host '  然后重新打开 WPS。'
Write-Host ''
Write-Host '重开后，功能区应出现「便捷插件」选项卡，'
Write-Host '内含：千分符、乘以一万、除以一万、填充序号、区域求和。'
Write-Host ''
Write-Host '若没有出现：把 publish.xml 里的 enable="enable_dev" 改成 enable="enable"，再重启 WPS。'
Write-Host '卸载：双击「卸载.bat」。'
Write-Host ''

# ---------- 生成 dsh-config.js ----------
# WPS 云盘的文件会同步成本地真实路径，但路径里含【用户名】和【账号 uid】，每台机器都不同，
# 插件无法硬编码。所以由安装脚本在这里搜一次，把实际路径写进配置交给插件用。
$VersionFile = 'dsh-version.js'
$UpdateUrl = ''

# ① 优先读同目录的 update-url.txt（手动指定 HTTP 地址，最可靠）
$urlFile = Join-Path $PSScriptRoot 'update-url.txt'
if (Test-Path $urlFile) {
    # 逐行找第一个非注释行。
    # ⚠️ 不能用 Get-Content -Raw 再判 '^\s*#'：包里的 update-url.txt 带注释头，
    #    整段会被误判成注释而全份跳过 —— 这个 bug 真的发出去过一次，
    #    表现是同事装完点「检查更新」提示「还没有配置更新检查地址」。
    $u = ''
    foreach ($ln in @(Get-Content $urlFile -Encoding UTF8)) {
        $s = $ln.Trim()
        if ($s -and $s -notmatch '^#') { $u = $s; break }
    }
    if ($u) {
        $UpdateUrl = $u
        Write-Host '更新检查地址取自 update-url.txt'
    }
}

# ② 没手动指定才去云盘找。
#    ⚠️ 云盘文件是「按需下载」的占位符（属性含 OFFLINE + RECALL_ON_DATA_ACCESS），
#    读它要联网回拉，实测可能极慢。所以这条路只作兜底，不推荐。
$driveRoot = Join-Path $env:USERPROFILE 'WPSDrive'
if (Test-Path $driveRoot) {
    $cloudRoots = @()
    foreach ($u in @(Get-ChildItem $driveRoot -Directory -ErrorAction SilentlyContinue)) {
        foreach ($c in @(Get-ChildItem $u.FullName -Directory -ErrorAction SilentlyContinue)) {
            if ($c.Name -match '云盘|Cloud') { $cloudRoots += $c.FullName }
        }
    }
    foreach ($cr in $cloudRoots) {
        $hit = Get-ChildItem $cr -Recurse -Depth 3 -Filter $VersionFile -File -ErrorAction SilentlyContinue |
               Select-Object -First 1
        if ($hit) { $UpdateUrl = ([System.Uri]$hit.FullName).AbsoluteUri; break }
    }
}
$cfgPath = Join-Path $Target 'dsh-config.js'
$cfg = "/* 本文件由安装脚本生成，请勿手改 —— 改动会在下次安装时被覆盖 */" + "`r`n" +
       "var DSH_UPDATE_URL = '" + $UpdateUrl + "';" + "`r`n"
[System.IO.File]::WriteAllText($cfgPath, $cfg, (New-Object System.Text.UTF8Encoding($false)))

if ($UpdateUrl) { Write-Host ('已找到版本清单 -> ' + $UpdateUrl) }

# ---------- 注册开机自动更新（HKCU Run，无需管理员）----------
# 为什么不靠 WPS 拉起更新器：
#   实测 wps.OAAssist.ShellExecute 调用不报错、WPS 也会弹安全确认框，
#   但更新器【根本没被执行】——证据是版本没变、结果文件没生成。
#   所以走独立通道：登录时由 Windows 启动，完全不经过 WPS 沙箱。
$runKey = 'HKCU:\Software\Microsoft\Windows\CurrentVersion\Run'
$updScript = Join-Path $Target 'updater.ps1'
if (Test-Path $updScript) {
    $runCmd = 'powershell.exe -NoProfile -ExecutionPolicy Bypass -WindowStyle Hidden -File "' + $updScript + '" -Daily'
    try {
        New-ItemProperty -Path $runKey -Name 'BianjieToolsUpdater' -Value $runCmd -PropertyType String -Force | Out-Null
        Write-Host '已注册开机自动更新（可在 任务管理器 → 启动 里看到并关闭）'
    } catch { Write-Host ('注册开机自动更新失败（不影响插件使用）: ' + $_.Exception.Message) }
}
else { Write-Host '未找到 dsh-version.js（不影响使用，只是「检查更新」不提示）' }
# ---------- 清理历史遗留的自定义 URL 协议 ----------
# 早期版本注册过 bianjie-update:// 想绕开 WPS 沙箱，实测无效，
# 而且在没注册过的机器上会让 Windows 弹「获取打开此链接的应用」——纯干扰。
# 这里主动删掉，保证升级上来的机器也干净。
try {
    if (Test-Path 'HKCU:\Software\Classes\bianjie-update') {
        Remove-Item 'HKCU:\Software\Classes\bianjie-update' -Recurse -Force -ErrorAction SilentlyContinue
        Write-Host '已清理历史遗留的 bianjie-update:// 协议'
    }
} catch { }