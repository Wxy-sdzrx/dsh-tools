@echo off
rem BianjieTools updater launcher. Keep this file CRLF and WITHOUT BOM,
rem and keep comments ASCII-only: cmd requires CRLF, and an LF-only .bat
rem gets mis-parsed so that rem lines are executed as commands.
rem %~dp0 is this file's own folder, so no path needs to be passed in.
powershell -NoProfile -ExecutionPolicy Bypass -File "%~dp0updater.ps1"
