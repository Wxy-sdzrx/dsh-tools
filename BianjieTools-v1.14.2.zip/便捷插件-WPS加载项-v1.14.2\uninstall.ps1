﻿<#
  便捷插件 · WPS 文字加载项 —— 卸载
  双击同目录的「卸载.bat」即可。只摘掉自己的条目，不动 publish.xml 里别人的加载项。
#>
$ErrorActionPreference = 'Continue'
try { [Console]::OutputEncoding = [System.Text.Encoding]::UTF8 } catch {}

$Name     = 'BianjieTools'
$Version  = '1.14.2'
$JsAddons = Join-Path $env:APPDATA 'kingsoft\wps\jsaddons'
$Target   = Join-Path $JsAddons ($Name + '_' + $Version)
$Pub      = Join-Path $JsAddons 'publish.xml'

# ---------- 清理 authaddin.json 里的历史残留（2026-10-20 质检 Q-04）----------
# WPS 会把加载项登记在 authaddin.json 里，path 指向具体版本目录。
# 旧版本目录被删掉后，这些记录就指向"不存在的加载项"，
# WPS 启动时仍会去尝试加载 —— 卸载后留残骸就是这么来的。
# 装和卸都要清一次。
function Remove-LegacyAuthEntries {
    $authFile = Join-Path $JsAddons 'authaddin.json'
    if (-not (Test-Path $authFile)) { return }
    try {
        $j = Get-Content $authFile -Raw -Encoding UTF8 | ConvertFrom-Json
        $w = $j.wps
        if ($w -eq $null) { return }
        $drop = @()
        foreach ($p in @($w.PSObject.Properties)) {
            if ($p.Name -eq 'namelist') { continue }
            $nm = [string]$p.Value.name
            $pth = [string]$p.Value.path
            if ($nm -eq $Name -or $pth -match '(BianjieTools|DshNumberTools|DadiJiubuTools)_') { $drop += $p.Name }
        }
        if ($drop.Count -eq 0) { return }
        foreach ($d in $drop) { $w.PSObject.Properties.Remove($d) }
        if ($w.namelist) {
            $parts = @(([string]$w.namelist) -split ';' | Where-Object { $_ -and ($drop -notcontains $_) })
            $w.namelist = ($parts -join ';')
        }
        $json = $j | ConvertTo-Json -Depth 6
        [System.IO.File]::WriteAllText($authFile, $json, (New-Object System.Text.UTF8Encoding($false)))
        Write-Host ('已清理 authaddin.json 里的历史残留条目: ' + ($drop -join ', '))
    } catch {
        Write-Host ('authaddin.json 清理失败（不影响插件使用）: ' + $_.Exception.Message)
    }
}

Write-Host ''
Write-Host '=== 便捷插件 · 卸载 ===' -ForegroundColor Cyan

if (Test-Path $Pub) {
    try {
        [xml]$doc = Get-Content $Pub -Raw -Encoding UTF8
        $rootEl = $doc.DocumentElement
        $removed = 0
        foreach ($n in @($rootEl.SelectNodes('jsplugin'))) {
            if ($n.GetAttribute('name') -eq $Name) { $rootEl.RemoveChild($n) | Out-Null; $removed++ }
        }
        $doc.Save($Pub)
        Write-Host ('已从 publish.xml 移除 ' + $removed + ' 条配置')
    } catch { Write-Host ('publish.xml 处理失败: ' + $_.Exception.Message) }
}

if (Test-Path $Target) {
    Remove-Item $Target -Recurse -Force -ErrorAction SilentlyContinue
    Write-Host ('已删除: ' + $Target)
Remove-LegacyAuthEntries
}

Write-Host ''
Write-Host '卸载完成。重启 WPS 生效。'
Write-Host ''

# ---------- 摘掉开机自动更新 ----------
try {
    Remove-ItemProperty -Path 'HKCU:\Software\Microsoft\Windows\CurrentVersion\Run' -Name 'BianjieToolsUpdater' -ErrorAction SilentlyContinue
    Write-Host '已移除开机自动更新'
} catch { }
# ---------- 摘掉自定义 URL 协议 ----------
try {
    Remove-Item 'HKCU:\Software\Classes\bianjie-update' -Recurse -Force -ErrorAction SilentlyContinue
    Write-Host '已移除 bianjie-update:// 协议'
} catch { }