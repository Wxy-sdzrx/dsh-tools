﻿<#
  便捷插件 · WPS 文字加载项 —— 卸载
  双击同目录的「卸载.bat」即可。只摘掉自己的条目，不动 publish.xml 里别人的加载项。
#>
$ErrorActionPreference = 'Continue'
try { [Console]::OutputEncoding = [System.Text.Encoding]::UTF8 } catch {}

$Name     = 'BianjieTools'
$Version  = '1.9.7'
$JsAddons = Join-Path $env:APPDATA 'kingsoft\wps\jsaddons'
$Target   = Join-Path $JsAddons ($Name + '_' + $Version)
$Pub      = Join-Path $JsAddons 'publish.xml'

Write-Host ''
Write-Host '=== 便捷插件 · 卸载 ===' -ForegroundColor Cyan

if (Test-Path $Pub) {
    try {
        [xml]$doc = Get-Content $Pub -Raw -Encoding UTF8
        $rootEl = $doc.DocumentElement
        $removed = 0
        foreach ($n in @($rootEl.SelectNodes('jsplugin'))) {
            if ($n.GetAttribute('name') -eq $Name) { $rootEl.RemoveChild($n) | Out-Null; $removed++ }
        }
        $doc.Save($Pub)
        Write-Host ('已从 publish.xml 移除 ' + $removed + ' 条配置')
    } catch { Write-Host ('publish.xml 处理失败: ' + $_.Exception.Message) }
}

if (Test-Path $Target) {
    Remove-Item $Target -Recurse -Force -ErrorAction SilentlyContinue
    Write-Host ('已删除: ' + $Target)
}

Write-Host ''
Write-Host '卸载完成。重启 WPS 生效。'
Write-Host ''

# ---------- 摘掉开机自动更新 ----------
try {
    Remove-ItemProperty -Path 'HKCU:\Software\Microsoft\Windows\CurrentVersion\Run' -Name 'BianjieToolsUpdater' -ErrorAction SilentlyContinue
    Write-Host '已移除开机自动更新'
} catch { }
# ---------- 摘掉自定义 URL 协议 ----------
try {
    Remove-Item 'HKCU:\Software\Classes\bianjie-update' -Recurse -Force -ErrorAction SilentlyContinue
    Write-Host '已移除 bianjie-update:// 协议'
} catch { }